# Lago de datos sobre seguridad en Medellín

Periodo de análisis: enero a noviembre de 2022 y de 2023.
Fecha de descarga y comprobación: 2026-11-03 (America/Bogota).

## Archivos
- homicidios_mensuales.csv: anio, mes, codigo_comuna, cantidad.
- hurtos_personas_mensuales.csv: anio, mes, codigo_comuna, cantidad.
- poblacion_anual.csv: anio, codigo_comuna, nombre_comuna, poblacion.

Los archivos de delitos conservan las combinaciones observadas, sin rellenar
ausencias como cero. Cada cantidad suma el campo original cantidad. No se
guardan microdatos ni coordenadas. SIN_DATO se conserva como categoría y no
se asigna a ningún territorio ni se usa en tasas por comuna.

El XLSX de población tiene varias áreas geográficas para algunos corregimientos.
Se sumaron por código y año, excluyendo la fila Totales. Las sumas de población
coinciden con los totales oficiales del libro. La versión es la actualizada en 2025.

Para tasas del periodo: sumar los meses 1–11 para cada código y año, unir con
la población del mismo año y calcular cantidad / poblacion * 100000. El resultado
es una tasa acumulada de once meses, no una tasa anual ni una probabilidad
individual. La población residente no mide población flotante ni exposición
de turistas o visitantes. No sumar homicidios con hurtos como si fueran una
misma unidad. Los registros no estiman el total de hechos no denunciados.

Las fichas F01 y F02 se modificaron en marzo de 2025, pero los CSV llegan
solo a noviembre de 2023. No presentar este lago como situación actual de 2026
ni comparar esos once meses con años completos. La ausencia de un mes en
la fuente impide asegurar completitud solo por una fecha de actualización.

## Atribución y licencia
F01 Homicidio. Alcaldía de Medellín, Secretaría de Seguridad y Convivencia,
SISC. Ficha: https://medata.app.medellin.gov.co/node/16761
F02 Hurto a persona. Alcaldía de Medellín, Secretaría de Seguridad y Convivencia,
SISC; registros de Policía Nacional. Ficha: https://medata.app.medellin.gov.co/node/16764
Ambas fichas declaran https://creativecommons.org/licenses/by-sa/4.0/legalcode
Los dos CSV agregados son adaptaciones, con atribución a las fuentes,
y se comparten bajo la misma licencia CC BY-SA 4.0.

F03 Proyecciones de Población, DANE y Departamento Administrativo de Planeación
de Medellín. Actualización declarada: 2025-07-30. Ficha: https://www.medellin.gov.co/es/centro-documental/proyecciones-poblacion-viviendas-y-hogares/
Licencia específica: no declara en la ficha y libro revisados. No se extiende
la licencia de F01/F02 a este archivo por analogía.

## Descargas verificadas y trazabilidad

F01
URL: https://medata.app.medellin.gov.co/sites/default/files/distribution/1-027-23-000008/homicidio.csv
HTTP: 200
Bytes: 7070197
SHA-256 del archivo original descargado: 51465e810749f4091ecb127e16d9db44e8c7ac305180c76dea334e8579e47364

F02
URL: https://medata.app.medellin.gov.co/sites/default/files/distribution/1-027-23-000011/hurto_a_persona.csv
HTTP: 200
Bytes: 124482690
SHA-256 del archivo original descargado: bc5f9ffdc682a7d4e9109c296c8dd22f3efcee583695acd8fae9c88496df6af5

F03
URL: https://www.medellin.gov.co/es/wp-content/uploads/2022/08/1.-Proyecciones-Medellin-por-Comunas-y-Corregimientos-2018-2030-Actualizado.xlsx
HTTP: 200
Bytes: 110758
SHA-256 del archivo original descargado: 4e5fa0c980ab8b23575b2688066910159c5bfcf01c8678f8e02a1808f37b1e4c
